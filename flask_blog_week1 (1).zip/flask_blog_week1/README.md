# Flask Blog Management System — Week 1

A starter Flask application for a seven-week internship project.

## Week 1 deliverables

- Flask application factory (`create_app`)
- Modular project structure using a Blueprint
- SQLAlchemy database configuration
- Flask-Migrate integration
- Basic homepage using a Jinja2 template
- `requirements.txt` and `.gitignore`

## Requirements

- Python 3.10 or newer
- pip

## Run locally

```bash
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the application:

```bash
python run.py
```

Open `http://127.0.0.1:5000` in your browser.

## Initialize database migrations

Run these commands from the project root:

```bash
flask --app run.py db init
flask --app run.py db migrate -m "Initial database setup"
flask --app run.py db upgrade
```

The migration initialization command is normally run only once. Commit the generated `migrations/` folder to GitHub.

## Project structure

```text
flask_blog_week1/
├── app/
│   ├── main/
│   │   ├── __init__.py
│   │   └── routes.py
│   ├── static/css/style.css
│   ├── templates/
│   │   ├── base.html
│   │   └── home.html
│   ├── __init__.py
│   └── models.py
├── config.py
├── run.py
├── requirements.txt
└── README.md
```

## Notes

This is Week 1 only. User authentication, posts, tags, comments, search, tests and deployment are intentionally reserved for their respective weeks.
For anything beyond local development, set a strong `SECRET_KEY` environment variable.
