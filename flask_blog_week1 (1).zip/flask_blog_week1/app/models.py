from app import db

# Week 1 starter model: confirms SQLAlchemy is configured.
# User, Post, Tag and Comment models will be added in later weeks.
class HealthCheck(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    status = db.Column(db.String(30), nullable=False, default="working")
