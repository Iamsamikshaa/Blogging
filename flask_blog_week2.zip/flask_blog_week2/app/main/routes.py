from flask import render_template
from flask_login import current_user, login_required
from app.main import main_bp

@main_bp.route("/")
def home():
    return render_template("home.html", title="Flask Blog")

@main_bp.route("/profile")
@login_required
def profile():
    return render_template("profile.html", title="My Profile", user=current_user)
