# Flask Blog Management System — Weeks 1 & 2

A Flask project implementing the first two weeks of a seven-week blog internship.

## Week 1
- Flask application factory and Blueprints
- SQLAlchemy and Flask-Migrate setup
- Jinja2 homepage and Bootstrap styling

## Week 2
- User model with unique username and email
- Registration, login and logout
- Flask-Login session management and protected profile
- Werkzeug password hashing (passwords are not stored as plain text)
- Flask-WTF validation and CSRF protection
- Duplicate username/email checks and safe next-page redirects

## Run locally
Requires Python 3.10+.

```bash
python -m venv .venv
```
Activate it (Windows: `.venv\\Scripts\\activate`; macOS/Linux: `source .venv/bin/activate`).

```bash
pip install -r requirements.txt
python init_db.py
python run.py
```
Open `http://127.0.0.1:5000`.

## Optional database migrations
Run once to initialize migrations, then use migrate/upgrade after model changes:

```bash
flask --app run.py db init
flask --app run.py db migrate -m "Add user authentication"
flask --app run.py db upgrade
```

## Manual verification checklist
1. Open the homepage and choose Register.
2. Create an account with a valid email and password of at least 8 characters.
3. Confirm you are redirected to your profile while logged in.
4. Log out from the navigation bar.
5. Visit `/profile` while logged out; it should redirect to the login page.
6. Log in with the same credentials.
7. Try a duplicate username/email and verify a validation message appears.
8. Confirm stored passwords are hashes, not readable plain text.

## Project structure
`app/auth/` contains authentication routes and forms; `app/main/` contains public/profile routes; `app/models.py` contains SQLAlchemy models; templates and CSS are in `app/templates/` and `app/static/`.

For public deployment, set a strong random `SECRET_KEY` environment variable. The included key is for local development only. Do not commit secrets or database files.
